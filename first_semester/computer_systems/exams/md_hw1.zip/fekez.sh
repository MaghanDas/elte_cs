#!/bin/bash


if [ $# -ne 1 ]
then
	echo "no or too many arguments"
	exit 1
fi


data_file="data.txt"

for i in $(seq 1 $(cat $data_file | wc -l))
do
	line=$( awk "NR==$i" $data_file)
	speed=$(echo "$line" | cut -f3 -d" ")
	time=$( echo "$line" | cut -f2 -d" ")

	if [ "$speed" -lt "$1" ]
	then
		echo "$time : Apply break"
	fi
done


	
