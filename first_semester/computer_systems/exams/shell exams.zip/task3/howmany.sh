#!/bin/bash


if test ! -f "$1";
then
	echo "files doesnt exist"
	exit
fi

cat $1 | grep 'a' |  wc -l
