#!/bin/bash

counter=1
for counter in 1 2 3 4 5 
do
	echo -n  "$1 "
done
echo 
