#!/bin/bash

if test -z "$1";  
then
	echo "no parameter passed"
	exit
fi

while IFS= read -r line
do
	
	sum=0

	for num in $line 
	do 
		sum=$((sum+num))
	done

	echo -n "$sum "


done <"$1"

echo 
