#!/bin/bash


if test "$#" != 2;
then
	echo "more or less parameters found:"
	exit 
fi

money=$1
rate=$2

total=$((money*rate))

echo "$total"


